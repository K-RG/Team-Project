// add schedule popup open
function click_add() {
	var url = "schedulePopup";
	var name = "schedulePopup";
	var option = "width = 800, height = 800 left = 100, top=50,location=no";
	window.open(url,name,option)
};

