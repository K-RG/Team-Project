package tobe.project.dto;

public class EmailDTO {
	private int midx;
	private String m_addressee;
	private String m_senddate;
	private String m_title;
	private String m_content;
	private String delyn;
	private int tidx;
	private String t_name;
	private String t_position;
	private String t_department;
	public int getMidx() {
		return midx;
	}
	public void setMidx(int midx) {
		this.midx = midx;
	}
	public String getM_addressee() {
		return m_addressee;
	}
	public void setM_addressee(String m_addressee) {
		this.m_addressee = m_addressee;
	}
	public String getM_senddate() {
		return m_senddate;
	}
	public void setM_senddate(String m_senddate) {
		this.m_senddate = m_senddate;
	}
	public String getM_title() {
		return m_title;
	}
	public void setM_title(String m_title) {
		this.m_title = m_title;
	}
	public String getM_content() {
		return m_content;
	}
	public void setM_content(String m_content) {
		this.m_content = m_content;
	}
	public String getDelyn() {
		return delyn;
	}
	public void setDelyn(String delyn) {
		this.delyn = delyn;
	}
	public int getTidx() {
		return tidx;
	}
	public void setTidx(int tidx) {
		this.tidx = tidx;
	}
	public String getT_name() {
		return t_name;
	}
	public void setT_name(String t_name) {
		this.t_name = t_name;
	}
	public String getT_position() {
		return t_position;
	}
	public void setT_position(String t_position) {
		this.t_position = t_position;
	}
	public String getT_department() {
		return t_department;
	}
	public void setT_department(String t_department) {
		this.t_department = t_department;
	}

}
