package tobe.project.dto;

public class CommuteVO {
	private int cidx;
	private String c_type;
	private String c_date;
	private String c_starttime;
	private String c_endtime;
	private String c_worktime;
	private String c_totlalworktime;
	private int tidx;
	
	public int getCidx() {
		return cidx;
	}
	public void setCidx(int cidx) {
		this.cidx = cidx;
	}
	public String getC_type() {
		return c_type;
	}
	public void setC_type(String c_type) {
		this.c_type = c_type;
	}
	public String getC_date() {
		return c_date;
	}
	public void setC_date(String c_date) {
		this.c_date = c_date;
	}
	public String getC_starttime() {
		return c_starttime;
	}
	public void setC_starttime(String c_starttime) {
		this.c_starttime = c_starttime;
	}
	public String getC_endtime() {
		return c_endtime;
	}
	public void setC_endtime(String c_endtime) {
		this.c_endtime = c_endtime;
	}
	public String getC_worktime() {
		return c_worktime;
	}
	public void setC_worktime(String c_worktime) {
		this.c_worktime = c_worktime;
	}
	public String getC_totlalworktime() {
		return c_totlalworktime;
	}
	public void setC_totlalworktime(String c_totlalworktime) {
		this.c_totlalworktime = c_totlalworktime;
	}
	public int getTidx() {
		return tidx;
	}
	public void setTidx(int tidx) {
		this.tidx = tidx;
	}
	
	
}
