package tobe.project.dto;

public class MemberDTO {
	private int	tidx;
	private String t_id;
	private String t_pwd;
	private String t_email;
	private String t_addr_zipcode;
	private String t_addr_general;
	private String t_addr_detail;
	private String t_phone;
	private String t_name;
	private String t_birth;
	private String t_position;
	private String t_department;
	private String t_join_date;
	private String t_leave_get;
	private String t_grade;
	private String delyn;
	private String f_type;
	private String f_stored_file_name;
	public int getTidx() {
		return tidx;
	}
	public void setTidx(int tidx) {
		this.tidx = tidx;
	}
	public String getT_id() {
		return t_id;
	}
	public void setT_id(String t_id) {
		this.t_id = t_id;
	}
	public String getT_pwd() {
		return t_pwd;
	}
	public void setT_pwd(String t_pwd) {
		this.t_pwd = t_pwd;
	}
	public String getT_email() {
		return t_email;
	}
	public void setT_email(String t_email) {
		this.t_email = t_email;
	}
	public String getT_addr_zipcode() {
		return t_addr_zipcode;
	}
	public void setT_addr_zipcode(String t_addr_zipcode) {
		this.t_addr_zipcode = t_addr_zipcode;
	}
	public String getT_addr_general() {
		return t_addr_general;
	}
	public void setT_addr_general(String t_addr_general) {
		this.t_addr_general = t_addr_general;
	}
	public String getT_addr_detail() {
		return t_addr_detail;
	}
	public void setT_addr_detail(String t_addr_detail) {
		this.t_addr_detail = t_addr_detail;
	}
	public String getT_phone() {
		return t_phone;
	}
	public void setT_phone(String t_phone) {
		this.t_phone = t_phone;
	}
	public String getT_name() {
		return t_name;
	}
	public void setT_name(String t_name) {
		this.t_name = t_name;
	}
	public String getT_birth() {
		return t_birth;
	}
	public void setT_birth(String t_birth) {
		this.t_birth = t_birth;
	}
	public String getT_position() {
		return t_position;
	}
	public void setT_position(String t_position) {
		this.t_position = t_position;
	}
	public String getT_department() {
		return t_department;
	}
	public void setT_department(String t_department) {
		this.t_department = t_department;
	}
	public String getT_join_date() {
		return t_join_date;
	}
	public void setT_join_date(String t_join_date) {
		this.t_join_date = t_join_date;
	}
	public String getT_leave_get() {
		return t_leave_get;
	}
	public void setT_leave_get(String t_leave_get) {
		this.t_leave_get = t_leave_get;
	}
	public String getT_grade() {
		return t_grade;
	}
	public void setT_grade(String t_grade) {
		this.t_grade = t_grade;
	}
	public String getDelyn() {
		return delyn;
	}
	public void setDelyn(String delyn) {
		this.delyn = delyn;
	}
	public String getF_type() {
		return f_type;
	}
	public void setF_type(String f_type) {
		this.f_type = f_type;
	}
	public String getF_stored_file_name() {
		return f_stored_file_name;
	}
	public void setF_stored_file_name(String f_stored_file_name) {
		this.f_stored_file_name = f_stored_file_name;
	}
}
